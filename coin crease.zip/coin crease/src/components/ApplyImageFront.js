import React, { Component } from 'react'
import StringData from '../context/StringData';
import {withStyles, createStyles, Avatar, CircularProgress} from '@material-ui/core';
import {storage, db} from './firebase';

const styles = theme => createStyles({
    input: {
        position: 'absolute',
        width: '40px',
        height: '40px',
        left: '0px',
        outline: '0',
        zIndex: '-1',
        opacity: 0
    },
});

class ApplyImageFront extends Component {
    constructor() {
        super()
        this.state = {
            photoUrl: localStorage.getItem(StringData.FrontView),
            id: localStorage.getItem(StringData.ID),
            message: '',
            email: localStorage.getItem(StringData.Email),
            error: null,
            loading: false
        }
        this.newPhoto = null
        this.newPhotoUrl = ''
        this.handleImageChange = this.handleImageChange.bind(this);
        this.uploadImage = this.uploadImage.bind(this);
        this.updateUserInfo = this.updateUserInfo.bind(this);
    }

    handleImageChange = (e) => {
        if(e.target.files && e.target.files[0]) {
            const prefixFileType = e.target.files[0].type.toString();
            if(prefixFileType.indexOf(StringData.PREFIX_IMAGE) !== 0 ) {
                return
            }
            this.newPhoto = e.target.files[0];
            this.setState({
                photoUrl: URL.createObjectURL(e.target.files[0]),
                error: null  
            })
        }else{
            return
        }
    }

    uploadImage = (e) => {
        e.preventDefault();
        this.setState({
            loading: true,
            message: '',
            error: null,
            loading: true
        });

        if(this.newPhoto){
            const uploadTask = storage.ref(`/frontViewImages/${this.state.email}`).put(this.newPhoto);
            uploadTask.on(StringData.UPLOAD_CHANGED, null, err => {
                this.setState({loading: false})
            },
            () => {
                uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                    this.updateUserInfo(true, downloadURL)
                })
            }
            )
        }else{
            this.updateUserInfo(false, null)
            this.setState({
                loading: false,
                error: 'Please Input a valid ID.'
            })
        }
    }

    updateUserInfo = (updatedPhotoURL, downloadURL) => {
        let newinfo
        if(updatedPhotoURL) {
            newinfo = {
                FrontView: downloadURL
            }
        }else {
           return
        }
        db.collection('Application IDs FrontView').doc().set({
            FrontView: newinfo,
            id: this.state.id,
            Email: this.state.email
        })
            if(updatedPhotoURL) {
                localStorage.setItem(StringData.FrontView, downloadURL)
            }
            this.setState({
                loading: false,
                message: 'Your Front view Image has been saved!'
            })
    }


    render() {
        const {classes} = this.props;
        return (
            <div>
                <div style={{display: 'flex', justifyContent: 'center'}} >
                           <Avatar src={this.state.photoUrl} variant='square' style={{width: '300px', height: '200px'}} />
                           </div>
                <div style={{display: 'flex', justifyContent: 'center', marginTop: '20px'}} >
                    <button onClick={(e) => {e.preventDefault(); this.refInput.click()}} style={{border: 'none', padding: '5px 10px', backgroundColor: '#F6CD2D', borderRadius: '5px'}} >Upload</button>
                    {this.state.loading ? (
                        <button onClick={this.uploadImage} style={{border: 'none', padding: '5px 10px', backgroundColor: '#F6CD2D', borderRadius: '5px', marginLeft: '10px'}} ><CircularProgress style={{position: 'relative', width: '20px', height: '20px' }} /></button>
                    ) : (
                        <button onClick={this.uploadImage} style={{border: 'none', padding: '5px 10px', backgroundColor: '#F6CD2D', borderRadius: '5px', marginLeft: '10px'}} >Save</button>
                    )}
                    <input 
                    ref = {el => {
                        this.refInput = el
                    }}
                    accept = 'image/*'
                    type ='file'
                    className={classes.input}
                    onChange={this.handleImageChange}
                    />
                </div>
                {this.state.message && <p style={{textAlign: 'center'}} >{this.state.message}</p>}
                {this.state.error && <p style={{textAlign: 'center', color: 'red'}} >{this.state.error}</p>}
            </div>
        )
    }
}

export default withStyles(styles)(ApplyImageFront);