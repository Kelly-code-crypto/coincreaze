import { Hidden } from '@material-ui/core'
import React from 'react'
import ApplyNowMobile from './ApplyNowMobile'

function ApplyNow() {
    return (
        <div>
           <Hidden smDown>
                Apply for Coincrease Loan Now
           </Hidden> 

            <ApplyNowMobile />
        </div>
    )
}

export default ApplyNow
