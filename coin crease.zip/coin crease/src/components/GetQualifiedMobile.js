import { Hidden, TextField } from '@material-ui/core'
import React, {useState} from 'react'
import { Link, useHistory } from 'react-router-dom';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import {MuiPickersUtilsProvider, KeyboardDatePicker,} from '@material-ui/pickers';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import InputMask from 'react-input-mask';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import Checkbox from '@material-ui/core/Checkbox';
import LockOpenOutlinedIcon from '@material-ui/icons/LockOpenOutlined';
import FooterMobile from './FooterMobile';
import StringData from '../context/StringData';


const details = [
    {
        displayName: 'Checking and Savings',
        idx: 1
    },
    {
        displayName: 'Savings Only',
        idx: 2
    },
    {
        displayName: 'Checking Only',
        idx: 3
    },
    {
        displayName: 'Neither',
        idx: 4
    }
]
const employDetails = [
    {
        displayName: 'Employed',
        idx: 1
    },
    {
        displayName: 'Self Employed',
        idx: 2
    },
    {
        displayName: 'Retired',
        idx: 3
    },
    {
        displayName: 'Student',
        idx: 4
    },
    {
        displayName: 'Unemployed',
        idx: 5
    },
    {
        displayName: 'Other',
        idx: 6
    },
]


function GetQualifiedMobile() {
    const [selectedDate, setSelectedDate] = useState(new Date('2014-08-18T21:11:54'));
    const history = useHistory()
    const [values, setValues] = useState({
        firstName: '',
        MI: '',
        lastName: '',
        ssn: '',
        residentialAddress: '',
        aptSuite: '',
        emailAddress: '',
        phoneNumber: '',
        annualIncome: '',
        monthlyIncome: ''
    });
    const [checking, setChecking] = useState('Checkings and Savings');
    const [employed, setEmployed] = useState('Checkings and Savings');
    const [error, setError] = useState(null)

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
      };

    const handleDateChange = (date) => {
        setSelectedDate(date);
      };

      const handleSubmit = (e) => {
          e.preventDefault();

          if(values.firstName === '' || values.MI === '' || values.lastName === '' || values.ssn === '' || values.residentialAddress === '' || values.aptSuite === '' || values.emailAddress === '' || values.phoneNumber === '' || checking === '' || employed === '' || values.annualIncome === '' || values.monthlyIncome === '' || selectedDate === '') {
            setError('No field must be empty.')
          } else {
            localStorage.setItem(StringData.firstName, values.firstName)
            localStorage.setItem(StringData.MI, values.MI)
            localStorage.setItem(StringData.lastName, values.lastName)
            localStorage.setItem(StringData.ssn, values.ssn)
            localStorage.setItem(StringData.residentialAddress, values.residentialAddress)
            localStorage.setItem(StringData.aptSuite, values.aptSuite)
            localStorage.setItem(StringData.emailAddress, values.emailAddress)
            localStorage.setItem(StringData.phoneNumber, values.phoneNumber)
            localStorage.setItem(StringData.checking, checking)
            localStorage.setItem(StringData.employed, employed)
            localStorage.setItem(StringData.annualIncome, values.annualIncome)
            localStorage.setItem(StringData.monthlyIncome, values.monthlyIncome)
            localStorage.setItem(StringData.DOB, selectedDate)
  
            history.push('/pre-qualify')
          }

      }

      const handleCheckSelect = (e) => {
        setChecking(e.target.value)
    }
      const handleEmployedSelect = (e) => {
        setEmployed(e.target.value)
    }

    return (
        <div>
            <Hidden mdUp>
                <header style={{height: '40px', padding: '5px 20px'}} >
                <Link style={{textDecoration: 'none', color: '#003970', textAlign: 'center', display: 'flex', alignItems: 'center'}} to='/get-a-loan' >
                    <ArrowBackIosIcon style={{fontSize: '20px'}}  />
                    <h5 style={{fontFamily: 'Montserrat Alternates', marginTop: '8px', fontSize: '20px'}} >Back </h5>
                </Link>
                </header>
                <div style={{width: '100%', height: '2px', backgroundColor: '#013972',}}></div>
                
                <div style={{padding: '0px 20px'}} >
                    <div style={{marginTop: '30px'}} >
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >1</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Pre-Approval Questions</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <div style={{width: '2px', height: '40px', backgroundColor: '#013972', marginLeft: '12px', marginTop: '-25px'}} ></div>
                            <p style={{marginLeft: '33px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >Tell us about yourself to see if you are pre-approved.</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >2</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Eligible Offers</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <div style={{width: '2px', height: '50px', backgroundColor: '#013972', marginLeft: '12px', marginTop: '-30px'}} ></div>
                            <p style={{marginLeft: '35px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >See the loans you are pre-approved for and choose the one best for you.</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center', marginTop: '-10px'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >3</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Shortened Application</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{marginLeft: '50px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >Answer a few more questions to finish applying for your loan.</p>
                        </div>
                    </div>

                    <form style={{paddingBottom: '50px'}} onSubmit={handleSubmit}  action="">
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='Legal First Name' type='text' name='name' value={values.firstName} onChange={handleChange('firstName')} />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='MI' type='text' name='name' value={values.MI} onChange={handleChange('MI')}  />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px'}} label='Legal Last Name' type='text' name='name' value={values.lastName} onChange={handleChange('lastName')} />
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <MuiPickersUtilsProvider utils={DateFnsUtils} >
                            <KeyboardDatePicker 
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="date-picker-inline"
                                label="Date of Birth"
                                value={selectedDate}
                                onChange={handleDateChange}
                                KeyboardButtonProps={{
                                  'aria-label': 'change date',
                                }}
                                style={{width: '90%'}}
                            />
                        </MuiPickersUtilsProvider>
                        </div>
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <InputMask placeholder='Social Security Number' mask="999-99-9999" style={{border: 'none', outline: 'none', borderBottom: '1px solid black', backgroundColor: 'transparent', padding: '10px', width: '90%', marginTop: '20px'}} value={values.ssn} onChange={handleChange('ssn')} />
                        </div>
                        <TextField fullWidth variant='outlined' style={{padding: '10px', margin: '20px auto',}} label='Residential Address (PO Box is not valid)' type='text' name='name' value={values.residentialAddress} onChange={handleChange('residentialAddress')} />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='Apt/Suite (If Applicable)' type='text' name='name' value={values.aptSuite} onChange={handleChange('aptSuite')}  />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '10px',}} label='Email Address' type='email' name='name' value={values.emailAddress} onChange={handleChange('emailAddress')} />
                        <div style={{display: 'flex', justifyContent: 'center', padding: '0px 20px'}} >
                        <p style={{fontSize: '12px', display: 'flex', justifyContent: 'center', fontWeight: 'bold', color: 'rgb(119, 119, 119)'}} >When you provide your email address, we may use it to send you important information about any offer(s) we may have for you, as well as other useful products or services.</p>
                        </div>
                       <div style={{display: 'flex', justifyContent: 'center'}}>
                       <InputMask placeholder='Primary Phone Number' mask="(999)-99-9999" style={{outline: 'none', border: '1px solid black', backgroundColor: 'transparent', padding: '10px 25px', width: '90%', borderColor: '#ccc', borderRadius: '5px'}} value={values.phoneNumber} onChange={handleChange('phoneNumber')} />
                       </div>
                       <div style={{display: 'flex', justifyContent: 'center', margin: '10px auto', marginTop: '20px'}} >
                       <select value={checking} onChange={handleCheckSelect} name="Language" id="" style={{  padding: '10px 20px', width: '300px', borderColor: '#ccc', borderRadius: '5px'}} >
                        {details.map((detail) => {
                            return <option key={detail.idx} value={detail.displayName}>{detail.displayName}</option>
                        })}
                        </select>
                       </div>
                       <div style={{display: 'flex', justifyContent: 'center', margin: '10px auto', marginTop: '20px'}} >
                       <select value={employed} onChange={handleEmployedSelect} name="Language" id="" style={{  padding: '10px 20px', width: '300px', borderColor: '#ccc', borderRadius: '5px'}} >
                        {employDetails.map((detail) => {
                            return <option key={detail.idx} value={detail.displayName}>{detail.displayName}</option>
                        })}
                        </select>
                       </div>
                       <div style={{display: 'flex', justifyContent: 'center', margin: '0px auto', marginTop: '30px'}} >
                       <div>
                       <InputLabel htmlFor="outlined-adornment-amount">Total Annual Income</InputLabel>
                        <OutlinedInput
                            id="outlined-adornment-amount"
                            // value={values.amount}
                            // onChange={handleChange('amount')}
                            startAdornment={<InputAdornment position="start">$</InputAdornment>}
                            labelWidth={180}
                            style={{width: '300px'}}
                            fullWidth
                            value={values.annualIncome}
                            onChange={handleChange('annualIncome')}
                        />
                       </div>
                       </div>
                       <div style={{display: 'flex', justifyContent: 'center', padding: '0px 20px', marginTop: '20px'}} >
                        <p style={{fontSize: '12px', display: 'flex', justifyContent: 'center', fontWeight: 'bold', color: 'rgb(119, 119, 119)'}} >Alimony, child support or separate maintenance income need not be revealed if you do not choose to have it considered as a basis for repaying this loan.</p>
                        </div>
                        <div style={{display: 'flex', justifyContent: 'center', margin: '0px auto', marginTop: '30px'}} >
                       <div>
                       <InputLabel htmlFor="outlined-adornment-amount">Monthly Rentage/Mortage</InputLabel>
                        <OutlinedInput
                            id="outlined-adornment-amount"
                            // value={values.amount}
                            // onChange={handleChange('amount')}
                            startAdornment={<InputAdornment position="start">$</InputAdornment>}
                            labelWidth={180}
                            style={{width: '300px'}}
                            fullWidth
                            value={values.monthlyIncome}
                            onChange={handleChange('monthlyIncome')}
                        />
                       </div>
                       </div>

                    <div style={{display: 'flex', justifyContent: 'center'}} >
                        <div style={{marginLeft: '10px'}} >
                        <p>We need your agreement to receive by electronic means only communications regarding Loan offer eligibility.</p>
                        <div style={{display: 'flex', marginTop: '40px'}} >
                            <div><Checkbox style={{color: '#003970' }}  inputProps={{ 'aria-label': 'uncontrolled-checkbox' }} /></div>
                            <div>
                                <p>I have reviewed and agree to the terms of the <a href='##' >Electronic Communications Disclosure</a> . I confirm that I have the ability to save or print web pages.</p>
                            </div>
                        </div>
                        <div style={{display: 'flex', marginTop: '40px'}} >
                            <div><Checkbox style={{color: '#003970' }}  inputProps={{ 'aria-label': 'uncontrolled-checkbox' }} /></div>
                            <div>
                                <p>By checking this box, I am providing written instructions to Coincreaze under the federal Fair Credit Reporting Act and applicable state law, authorizing Coincreaze to obtain information about me from consumer reporting agencies to determine if I am eligible for Loan offer(s). I understand that Coincreaze's <a href='##'>privacy policies</a> apply to the data that I am submitting and I understand that this is not a Loan application.</p>
                            </div>
                        </div>
                        </div>
                    </div>
                    {error && <p style={{color: "red", textAlign: 'center'}} >{error}</p>}
                    <div style={{display: 'flex', justifyContent: 'center', marginBottom: '20px'}} >
                        <button type='submit' style={{margin: '5px auto',  border: 'none', padding: '10px 50px', backgroundColor: '#003970', color: 'white', borderRadius: '5px', marginTop: '20px'}} >See If I'm Approved</button>
                    </div>
                    </form>

                    <div style={{display: 'flex', alignItems: 'center', marginTop: '-20px'}} >
                        <div><LockOpenOutlinedIcon style={{fontSize: '30px', marginTop: '-20px'}} /></div>
                        <p style={{fontSize: '12px', marginLeft: '10px'}} >Coincreaze supports 256-bit Transport Layer Security (TLS) technology. This means that when you are on our website, the data transferred between Coincreaze and you is encrypted and cannot be viewed by any other party.</p>
                    </div>

                </div>
                    <div style={{margin: '0px auto', width: '100%', marginTop: '50px'}} >
                    <FooterMobile />
                    </div>
            </Hidden>
        </div>
    )
}

export default GetQualifiedMobile
