import { Avatar } from '@material-ui/core';
import React from 'react';
import InstagramIcon from '@material-ui/icons/Instagram';
import TwitterIcon from '@material-ui/icons/Twitter';
import FacebookIcon from '@material-ui/icons/Facebook';

const languages = [
    {
        displayName: 'English',
        idx: 1
    },
    {
        displayName: 'Spanish',
        idx: 2
    },
    {
        displayName: 'Yoruba',
        idx: 3
    },
    {
        displayName: 'Scottish',
        idx: 4
    }
]

function FooterMobile() {
    return (
        <div>
            <footer style={{padding: '0px 20px', backgroundColor: 'white', paddingBottom: '20px', textAlign: 'center'}} >
                    <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}} >
                    <Avatar src='logo.png' variant='rounded' style={{width: '100px', height: '100px', marginLeft: '-20px'}} />
                    <h5 style={{marginTop: '10px', marginLeft: '-20px', color: '#06498B', }} >Coincreaze</h5>
                    </div>
                    <select name="Language" id="" style={{marginBottom: '10px', width: '200px'}} >
                        {languages.map((language) => {
                            return <option key={language.idx} value={language.displayName}>{language.displayName}</option>
                        })}
                    </select>
                    <p style={{color: 'rgb(119, 119, 119)'}} >© 2021 Coincreaze</p>
                    <div style={{display: 'flex', justifyContent: 'center'}} >
                        <a style={{color: '#06498B', textDecoration: 'none', margin: '0px 10px'}} href="https://www.instagram.com/coincreaze/"><InstagramIcon /></a>
                        <a style={{color: '#06498B', textDecoration: 'none', margin: '0px 10px'}} href="https://twitter.com/coincreaze?s=20"><TwitterIcon /></a>
                        <a style={{color: '#06498B', textDecoration: 'none', margin: '0px 10px'}} href=""><FacebookIcon /></a>
                    </div>
                    <div >
                        <div><h5 style={{fontWeight: 'bold', marginTop: '20px', color: '#06498B'}} >Company</h5></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">About</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Careers</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Affiliates</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Blog</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Press</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Investors</a></div>
                        <div><h5 style={{fontWeight: 'bold', marginTop: '20px', color: '#06498B'}} >Learn</h5></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Browse Crypto Prices</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Crypto Basics</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Tips & Tutorials</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Market Updates</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">What is Bitcoin?</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">What is Crypto?</a></div>
                        <div><h5 style={{fontWeight: 'bold', marginTop: '20px', color: '#06498B'}} >Individuals</h5></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Invest</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Earn free crypto</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Wallet</a></div>
                        <div><a style={{color: 'rgb(119, 119, 119)', textDecoration: 'none', }} href="#">Card</a></div>
                    </div>

                    <div style={{width: '100%', height: '2px', backgroundColor: '#ccc', margin: '20px auto'}} ></div>
                    
                    <div>
                        <p style={{textAlign: 'left', fontSize: '12px', color: 'rgb(131, 131, 131)'}} >© 2021 Coincreaze Grow Incorporated | Disclosures | Accessibility

                        This website is operated by Coincreaze Advisers, LLC, an SEC Registered Investment Advisor.  Brokerage services are provided to clients of Coincreaze Advisers by Coincreaze Securities, LLC, an SEC registered broker-dealer and member FINRA.  Member of SIPC. Securities in your account protected up to $500,000. For details, please see https://www.sipc.org.<br/><br/>

                        Important Disclosures:  Investing involves risk, including loss of principal.  Past performance does not guarantee or indicate future results.  Please consider, among other important factors, your investment objectives, risk tolerance and Coincreaze pricing before investing.<br/>  Diversification and asset allocation do not guarantee a profit, nor do they eliminate the risk of loss of principal.  It is not possible to invest directly in an index.  Any hypothetical performance shown is for illustrative purposes only. Such results do not represent actual results and do not take into consideration economic or market factors which can impact performance. Actual clients may achieve investment results materially different from the results portrayed. Round Up investments are transferred from your linked funding source (checking account) to your Coincreaze Invest account, where the funds are invested into a portfolio of selected ETFs. Only purchases made with a funding source linked to your Coincreaze account with the feature active are eligible for Round Up investments. Please note that a properly suggested portfolio recommendation is dependent upon current and accurate financial and risk profiles. Clients who have experienced changes to their goals, financial circumstances or investment objectives, or who wish to modify their portfolio recommendation, should promptly update their information in the Coincreaze app or through the website. Actual Found Money rewards investments are made by Coincreaze Grow, Inc. into your Coincreaze Invest account through a partnership Coincreaze Grow maintains with each Found Money partner.  Coincreaze Subscription Fees are assessed based on the tier of services in which you are enrolled.  Coincreaze does not charge transactional fees, commissions or fees based on assets for accounts under $1 million. Coincreaze Spend clients are not charged overdraft fees, maintenance fees, or ATM fees for cash withdrawals from ATMs within the Allpoint Network.  Please see your Coincreaze Subscription Center or Account Statements for a description of the fees you pay to Coincreaze for its services.  Third Party Quotes shown may not be representative of the experience of Coincreaze customers and do not represent a guarantee of future performance or success.  Please click on each testimonial to review the context from which this quote was taken. Coincreaze reserves the right to restrict or revoke any and all offers at any time.<br/>

                        Investors should consider the investment objectives, risks, charges and expenses of the funds carefully before investing.  This and other information are contained in the Fund’s prospectus.  Please read the prospectus carefully before you invest.<br/><br/>

                        Coincreaze also offers an Coincreaze Spend deposit account. Coincreaze Spend accounts are FDIC insured up to $250,000. Coincreaze Visa™ debit cards are issued by Lincoln Savings Bank, member FDIC for Coincreaze Spend account holders.  "Save and Invest" claim refers to a client's ability to utilize the Coincreaze Spend Instant Round-up feature to set aside small amounts of money from purchases made using an Coincreaze Spend account, and seamlessly investing those small amounts using an Coincreaze Investment account.  Requires both an active Coincreaze Spend account and an Coincreaze Investment account in good standing.  Instant Round-ups are accrued instantly for investment during the next trading window.<br/><br/>

                        For additional important risks, disclosures and information, please visit https://www.coincreaze.com

                        </p>
                    </div>
                </footer>
        </div>
    )
}

export default FooterMobile
