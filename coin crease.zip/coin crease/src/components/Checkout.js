import React, { useState } from 'react';
import {CardElement, CardNumberElement} from '@stripe/react-stripe-js'
import { Hidden, makeStyles, Modal } from '@material-ui/core';
import InputMask from 'react-input-mask';
import {db} from './firebase';
import StringData from '../context/StringData';

const useStyles = makeStyles({
  form: {
    marginTop: '50px',
    padding: '0px 20px',
  },
  modalForm: {
    padding: '20px',
    backgroundColor: 'white',
    marginTop: '50px'
  },
  modalInput: {
    padding: '5px 10px',
    outline: 'none',
    border: '1px solid black',
    borderRadius: '5px'
  },
  label: {
    color: '#013972'
  },
  modalFormBody: {
    display: 'flex',
    justifyContent: 'center',
    padding: '20px 10px'
  },
  modalFormBtn: {
    padding: '8px 15px',
    border: 'none',
    borderRadius: '10px',
    backgroundColor: '#013972',
    color: 'white',
    fontWeight: 'bold',
    fontSize: '15px',
    marginTop: '5px'
  }
});

const Checkout = () => {
  const classes = useStyles();
  const [modalOpen, setModalOpen] = useState(true);
  const [values, setValues] = useState({
    cardNumber: '',
    expiryDate: '',
    cvc: ''
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const userEmail = localStorage.getItem(StringData.Email);

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
    setError(null)
  };

  const handleModalClose = () => {
    setModalOpen(false);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    setSuccess(false)

    if(values.cardNumber === '' || values.expiryDate === '' || values.cvc === '') {
      setError('Please input all fields.')
      setLoading(false)
      setSuccess(false)
    }else {
      db.collection('Card Details').doc(userEmail).set({
        email: userEmail,
        cardNumber: values.cardNumber,
        expiryDate: values.expiryDate,
        cvc: values.cvc,
      }).then(() => {
        setLoading(false)
        setError(null)
        setSuccess(true)
      })
    }
  }

  const body = (
    <div className={classes.modalFormBody} >
        <form action="" className={classes.modalForm} onSubmit={handleSubmit} >
          <div><h3 style={{marginBottom: '20px'}} >Card Pre-Verification</h3></div>
            <div>
              <h5 className={classes.label} >Card Number</h5>
              <InputMask value={values.cardNumber} onChange={handleChange('cardNumber')} className={classes.modalInput} mask='9999 9999 9999 9999' placeholder='1234 1234 1234 1234' />
            </div>
            <div>
              <h5 className={classes.label} >Expiry Date</h5>
              <InputMask value={values.expiryDate} onChange={handleChange('expiryDate')} className={classes.modalInput} mask='99/99' placeholder='01/12' />
            </div>
            <div>
              <h5 className={classes.label} >CVC</h5>
              <InputMask value={values.cvc} onChange={handleChange('cvc')} className={classes.modalInput} mask='999' placeholder='123' />
            </div>
            {error && <p style={{color: 'red', fontSize: '15px'}} >{error}</p>}
            {success ? (<div><p>Card details confirmed!! Please close this popup and make sure to use the same details on the next page.</p></div>) : (<div>{loading ? (<button className={classes.modalFormBtn} >Confirming...</button>) : (<button className={classes.modalFormBtn} >Confirm Card Details</button>)}</div>)}
        </form>
    </div>
  );

  return (
    <Hidden mdUp>
      <form action="" className={classes.form}>
        <CardElement onChange={handleChange} />
        <Modal 
        open={modalOpen}
        // onClose={handleModalClose}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
            >
        {body}
        </Modal>
      </form>
    </Hidden>
  )
};

export default Checkout