import { Hidden } from '@material-ui/core'
import React from 'react'
import GetQualifiedMobile from './GetQualifiedMobile'

function GetQualified() {
    return (
        <div>
            <Hidden smDown>
                Get Qualified For Coincrease Loan
            </Hidden>

            <GetQualifiedMobile />
        </div>
    )
}

export default GetQualified
