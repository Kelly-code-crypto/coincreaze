import React from 'react';


function Toggler(props) {

    const changeTheme = () => {
        if(props.theme === 'light') {
            props.setTheme('dark')
        } else {
            props.setTheme('light')
        }
      };

    const toggle = props.theme === 'light' ? <h6>Dark Mode</h6> : <h6> Light Mode</h6>

    return (
        <div style={{marginTop: '-50px'}} >
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}} >
                <div>
                    {toggle}
                </div>

                <div>
                    <button onClick={changeTheme} >
                        Change
                    </button>
                </div>
            </div>
        </div>
    )
}

export default Toggler
