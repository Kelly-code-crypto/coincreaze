import React from 'react';
import CheckCircleOutlineOutlinedIcon from '@material-ui/icons/CheckCircleOutlineOutlined';
import { Link } from 'react-router-dom';
import {makeStyles} from '@material-ui/core';
import StringData from '../context/StringData'

const useStyles = makeStyles({
    applyBtn: {
        border: 'none',
        padding: '10px 25px',
        borderRadius: '5px',
        fontWeight: 'bold',
        backgroundColor: '#003970',
        color: 'white'
    }
});

function ApplySuccess() {
    const classes = useStyles();
    const Name = localStorage.getItem(StringData.FirstName);
    return (
        <div style={{display: 'flex', justifyContent: 'center'}} >
            <div style={{marginTop: '100px', textAlign: 'center'}} >
                <div><CheckCircleOutlineOutlinedIcon style={{color: 'green', fontSize: '50px', textAlign: 'center'}} /></div>
                <p>Success! {Name}, Your application has been submitted!</p>
                <p>Thanks for applying for Coincreaze Loan!<br/>So what's next? An email is headed your way shortly about your application status. If we can't reach you by email, you can look for a letter in the mail in about 7 to 15 business days.</p>

                <div>
                    <Link to='/get-a-loan' >
                        <button className={classes.applyBtn} >
                            Back to home page
                        </button>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default ApplySuccess
