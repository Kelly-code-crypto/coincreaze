import { Avatar, Hidden, TextField, makeStyles } from '@material-ui/core'
import React, {useState} from 'react'
import { Link, useHistory } from 'react-router-dom';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import {MuiPickersUtilsProvider, KeyboardDatePicker,} from '@material-ui/pickers';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import InputMask from 'react-input-mask';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import Checkbox from '@material-ui/core/Checkbox';
import LockOpenOutlinedIcon from '@material-ui/icons/LockOpenOutlined';
import FooterMobile from './FooterMobile';
import StringData from '../context/StringData';
import {db} from './firebase';
import ApplyImageUploader from './ApplyImageFront';
import ApplyImageFront from './ApplyImageFront';
import ApplyImageBack from './ApplyImageBack';

const useStyles = makeStyles({

});


const details = [
    {
        displayName: 'Checking and Savings',
        idx: 1
    },
    {
        displayName: 'Savings Only',
        idx: 2
    },
    {
        displayName: 'Checking Only',
        idx: 3
    },
    {
        displayName: 'Neither',
        idx: 4
    }
]
const employDetails = [
    {
        displayName: 'Please choose your identity document',
        idx: 1
    },
    {
        displayName: 'ID Card',
        idx: 2
    },
    {
        displayName: 'National ID',
        idx: 3
    },
    {
        displayName: "Voter's Card",
        idx: 4
    },
    {
        displayName: "Driver's License",
        idx: 5
    },
    {
        displayName: 'Other',
        idx: 6
    },
]


function ApplyNowMobile() {
    const classes = useStyles();
    const [selectedDate, setSelectedDate] = useState(new Date('2014-08-18T21:11:54'));
    const history = useHistory()
    const [values, setValues] = useState({
        firstName: '',
        MI: '',
        lastName: '',
        ssn: '',
    });
    const [error, setError] = useState(null);
    const [photoUrl, setPhotoUrl] = useState(null);
    const [card, setCard] = useState('Please choose your identity document');

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
      };

    const handleDateChange = (date) => {
        setSelectedDate(date);
      };

      const handleSubmit = (e) => {
          e.preventDefault();

        //   db.collection('Application Details').doc().set({
        //     FirstName: values.firstName,
        //     LastName: values.lastName,
        //     MI: values.MI,
        //     SSN: values.ssn,
        //     DOB: selectedDate
        // }).catch((e) => {
        //     setError(e);
        //     console.error(e)
        // })
        if(values.firstName === '' || values.lastName === '' || values.MI === '' || values.ssn === '' || selectedDate === '') {
            return (
                setError('No field must be empty.')
            )
        } else {
          localStorage.setItem(StringData.ApplyFirstname, values.firstName)
          localStorage.setItem(StringData.ApplyMI, values.MI)
          localStorage.setItem(StringData.ApplyLastname, values.lastName)
          localStorage.setItem(StringData.ApplySSN, values.ssn)
          localStorage.setItem(StringData.ApplyDOB, selectedDate)
          localStorage.setItem(StringData.ApplyCard, card)

          history.push('/confirm-application-details')

        }
      }

      const handleCardSelect = (e) => {
        setCard(e.target.value)
    }

    return (
        <div>
            <Hidden mdUp>
                <header style={{height: '40px', padding: '5px 20px'}} >
                <Link style={{textDecoration: 'none', color: '#003970', textAlign: 'center', display: 'flex', alignItems: 'center'}} to='/get-a-loan' >
                    <ArrowBackIosIcon style={{fontSize: '20px'}}  />
                    <h5 style={{fontFamily: 'Montserrat Alternates', marginTop: '8px', fontSize: '20px'}} >Back </h5>
                </Link>
                </header>
                <div style={{width: '100%', height: '2px', backgroundColor: '#013972',}}></div>
                
                <div style={{padding: '0px 20px'}} >
                    <div style={{marginTop: '30px'}} >
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >1</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Pre-Approval Questions</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <div style={{width: '2px', height: '40px', backgroundColor: '#013972', marginLeft: '12px', marginTop: '-25px'}} ></div>
                            <p style={{marginLeft: '33px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >Tell us about yourself to see if you are pre-approved.</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >2</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Eligible Offers</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <div style={{width: '2px', height: '50px', backgroundColor: '#013972', marginLeft: '12px', marginTop: '-30px'}} ></div>
                            <p style={{marginLeft: '35px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >See the loans you are pre-approved for and choose the one best for you.</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center', marginTop: '-10px'}} >
                            <p style={{border: '1px solid #013972', borderRadius: '100px', padding: '2px 10px', color: 'white', fontWeight: 'bold', backgroundColor: '#013972'}} >3</p>
                            <p style={{marginLeft: '20px', color: '#013972', fontWeight: 'bold'}} >Shortened Application</p>
                        </div>
                        <div style={{display: 'flex', alignItems: 'center'}} >
                            <p style={{marginLeft: '50px', color: 'black', fontSize: '12px', marginTop: '-15px', width: '200px'}} >Answer a few more questions to finish applying for your loan.</p>
                        </div>
                    </div>

                    <form style={{paddingBottom: '50px'}} onSubmit={handleSubmit}  action="">
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='Legal First Name' type='text' name='name' value={values.firstName} onChange={handleChange('firstName')} />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='MI' type='text' name='name' value={values.MI} onChange={handleChange('MI')}  />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px'}} label='Legal Last Name' type='text' name='name' value={values.lastName} onChange={handleChange('lastName')} />
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <MuiPickersUtilsProvider utils={DateFnsUtils} >
                            <KeyboardDatePicker 
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="date-picker-inline"
                                label="Date of Birth"
                                value={selectedDate}
                                onChange={handleDateChange}
                                KeyboardButtonProps={{
                                  'aria-label': 'change date',
                                }}
                                style={{width: '90%'}}
                            />
                        </MuiPickersUtilsProvider>
                        </div>
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <InputMask placeholder='Social Security Number' mask="999-99-9999" style={{border: 'none', outline: 'none', borderBottom: '1px solid black', backgroundColor: 'transparent', padding: '10px', width: '90%', marginTop: '20px'}} value={values.ssn} onChange={handleChange('ssn')} />
                        </div>

                        <div style={{display: 'flex', justifyContent: 'center', margin: '10px auto', marginTop: '20px'}} >
                       <select value={card} onChange={handleCardSelect} name="Language" id="" style={{  padding: '10px 20px', width: '300px', borderColor: '#ccc', borderRadius: '5px'}} >
                        {employDetails.map((detail) => {
                            return <option key={detail.idx} value={detail.displayName}>{detail.displayName}</option>
                        })}
                        </select>
                       </div>

                       <div style={{textAlign: 'center'}} >
                           {card === "Please choose your identity document" ? (<p>Your Identity Details</p>) : (<p>Upload your "{card}" details in the right format below.</p>)}
                       </div>

                       <div>
                           <h6 style={{textAlign: 'center'}} >Front View</h6>
                           
                           <ApplyImageFront />
                       </div>
                       <div style={{marginTop: '20px'}} >
                           <h6 style={{textAlign: 'center'}} >Back View</h6>
                           <ApplyImageBack />
                       </div>

                       {error && <p style={{color: 'red', textAlign: 'center', marginTop: '20px'}} >{error}</p>}
                        
                    <div style={{display: 'flex', justifyContent: 'center', marginBottom: '20px'}} >
                        <button type='submit' style={{margin: '5px auto', border: 'none', padding: '10px 80px', backgroundColor: '#003970', color: 'white', borderRadius: '5px', marginTop: '20px'}} >Apply Now</button>
                    </div>
                    </form>

                    <div style={{display: 'flex', alignItems: 'center', marginTop: '-30px'}} >
                        <div><LockOpenOutlinedIcon style={{fontSize: '30px', marginTop: '-20px'}} /></div>
                        <p style={{fontSize: '12px', marginLeft: '10px'}} >Coincrease supports 256-bit Transport Layer Security (TLS) technology. This means that when you are on our website, the data transferred between Coincreaze and you is encrypted and cannot be viewed by any other party.</p>
                    </div>
                </div>
                <div style={{margin: '0px auto', width: '100%', marginTop: '50px'}} >
                    <FooterMobile />
                    </div>
            </Hidden>
        </div>
    )
}

export default ApplyNowMobile
