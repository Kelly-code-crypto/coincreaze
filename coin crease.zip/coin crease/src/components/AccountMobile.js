import React, { Component, useState } from 'react';
import {useAuth} from '../context/AuthContext'
import StringData from '../context/StringData';
import {Link} from 'react-router-dom'
import { Avatar, CircularProgress, Hidden, withStyles, createStyles, Button, TextField } from '@material-ui/core';
import {storage, db} from './firebase';
import Chart from './Chart';
import Header from './Header';
import CreateIcon from '@material-ui/icons/Create';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import styled from 'styled-components';
import Toggler from './Toggler';
import {ThemeProvider} from 'styled-components';

const styles = theme => createStyles({
    root: {
        backgroundColor: 'white',
        overflowX: 'none'
    },
    back: {
       marginLeft: '150px'
    },
    profile: {
        backgroundColor: 'transparent',
        padding: '70px 0px',
        margin: '0px auto',
        marginTop: '0px',
        // width: '400px',
        // display: 'flex',
        // alignItems: 'center',
        // justifyContent: 'center',
        borderTopLeftRadius: '20px',
        borderBottomLeftRadius: '20px',
        height: '100%'
    },
    avatar: {
        width: '80px',
        height: '80px',
        marginBottom: '20px',
        margin: '10px auto',
        marginTop: '-20px'
    },
    input: {
        position: 'absolute',
        width: '40px',
        height: '40px',
        left: '0px',
        outline: '0',
        zIndex: '-1',
        opacity: 1
    },
    loading: {
        // position: 'absolute'
    },
    profileBody: {
        backgroundColor: 'transparent',
        // display: 'flex',
        // alignItems: 'center',
        // justifyContent: 'center',
        marginTop: '0px',
        padding: '0px 0px',
        borderRadius: '20px',
        margin: '10px auto',
    }
});

const Root = styled.div`
    background-color: ${props => props.theme.backgroundColor};
`
const HeaderHead = styled.header`
    background-color: ${props => props.theme.headerBgColor};
`
const Divider = styled.div`
    background-color: ${props => props.theme.dividerColor};
`
const H6 = styled.h6`
    color: ${props => props.theme.h6Color};
`
const P = styled.p`
    color: ${props => props.theme.pColor};
`
const Title = styled.h3`
    color: ${props => props.theme.titleColor};
`



  


class AccountMobile extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            documentKey: localStorage.getItem(StringData.FirebaseDocumentId),
            id: localStorage.getItem(StringData.ID),
            name: localStorage.getItem(StringData.FirstName),
            lastName: localStorage.getItem(StringData.LastName),
            aboutMe: localStorage.getItem(StringData.Description),
            photoUrl: localStorage.getItem(StringData.PhotoURL),
            message: '',
        }
        this.newPhoto = null
        this.newPhotoUrl = ''
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleImageChange = this.handleImageChange.bind(this);
        this.uploadImage = this.uploadImage.bind(this);
        this.updateUserInfo = this.updateUserInfo.bind(this);
        // this.LightTheme = {
        //     backgroundColor: 'white',
        //     // ACCOUNTS
        //     headerBgColor: 'white',
        //     dividerColor: '#013972',
        //     h6Color: 'black',
        //     pColor: 'black',
        //     titleColor: 'black'
        //   }
        // this.DarkTheme = {
        //     backgroundColor: '#013972',
        //     // ACCOUNTS
        //     headerBgColor: 'black',
        //     dividerColor: '#F6CD2D',
        //     h6Color: '#F6CD2D',
        //     pColor: '#ccc',
        //     titleColor: '#ccc'
        //   }
        // this.themes = {
        //     light: this.LightTheme,
        //     dark: this.DarkTheme
        //   }
    }

    componentDidMount() {
        if(!localStorage.getItem(StringData.ID)) {
            this.props.history.push('/')
        }
    }

    handleInputChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handleImageChange = (e) => {
        if(e.target.files && e.target.files[0]) {
            const prefixFileType = e.target.files[0].type.toString();
            if(prefixFileType.indexOf(StringData.PREFIX_IMAGE) !== 0 ) {
                return
            }
            this.newPhoto = e.target.files[0];
            this.setState({
                photoUrl: URL.createObjectURL(e.target.files[0])  
            })
        }else{
            return
        }
    }
    
    uploadImage = () => {
        this.setState({
            loading: true,
            message: ''
        })
        if(this.newPhoto){
            const uploadTask = storage.ref().child(this.state.id).put(this.newPhoto);
            uploadTask.on(StringData.UPLOAD_CHANGED, null, err => {
                this.setState({loading: false})
            },
            () => {
                uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                    this.updateUserInfo(true, downloadURL)
                })
            }
            )
        }else{
            this.updateUserInfo(false, null)
        }
    }

    updateUserInfo = (updatedPhotoURL, downloadURL) => {
        let newinfo
        if(updatedPhotoURL) {
            newinfo = {
                name: this.state.name,
                description: this.state.aboutMe,
                URL: downloadURL
            }
        }else {
            newinfo = {
                name: this.state.name,
                description: this.state.aboutMe,
            }
        }
        db.collection('users').doc(this.state.documentKey).update(newinfo).then(data => {
            localStorage.setItem(StringData.Name, this.state.name);
            localStorage.setItem(StringData.Description, this.state.aboutMe);
            if(updatedPhotoURL) {
                localStorage.setItem(StringData.PhotoURL, downloadURL)
            }
            this.setState({
                loading: false
            })
            this.setState({
                message: 'Your Profile has been updated successfully!'
            })
        })
    }

    

    // toggle = this.props.theme = 'light' ? <h6>Dark Mode</h6> : <h6> Light Mode</h6> 

    render() {
        const {classes} = this.props;
        const {photoUrl, name, aboutMe, loading, message, lastName} = this.state;
        return (
            // <ThemeProvider theme={this.themes[this.theme]}>
            <Hidden mdUp>
            <Root className={classes.root} >
            <HeaderHead style={{ height: '40px', display: 'flex', alignItems: 'center', padding: '10px 20px', color: '#F6CD2D'}} >
                    <Link to='/' style={{textDecoration: 'none', color: '#013972', display: 'flex', alignItems: 'center',}} >
                    <ArrowBackIosIcon style={{fontSize: '15px'}} />
                    <h5 style={{marginTop: '10px', fontSize: '15px'}} >Back Home</h5>
                    </Link>
                </HeaderHead>
                
                <Divider style={{width: '100%', height: '2px'}}></Divider>
               
            <div className={classes.profileBody} >
            
               <div className={classes.profile} >
                   <div>
                    
                   </div>
                   <div style={{textAlign: 'center', margin: '0px auto', width: '100%', marginTop: '80px' }} >
                       <div style={{display: 'flex', alignItems: 'center', marginTop: '20px'}} >
                        <div style={{display: 'flex', alignItems: 'center', marginTop: '-40px', marginLeft: '10px'}} >
                            <Avatar src={photoUrl} alt='' className={classes.avatar} />
                            <div style={{marginLeft: '10px'}} >
                                <H6 style={{fontWeight: 'bold', marginTop: '-20px', fontSize: '15px'}} >Change Picture</H6>
                                <P style={{fontSize: '10px'}} >Max file size is 20mb</P>
                            </div>
                        </div>
                        <div style={{marginTop: '-80px', marginLeft: '50px'}} >
                            <button onClick={() => {this.refInput.click()}} style={{border: '1px solid #ccc', padding: '2px 10px', borderRadius: '5px', fontWeight: 'bold'}} >Upload</button>
                            <input 
                            ref = {el => {
                                this.refInput = el
                            }}
                            accept = 'image/*'
                            type ='file'
                            className={classes.input}
                            onChange={this.handleImageChange}
                            />
                        </div>
                       </div>
                       <div style={{display: 'flex', alignItems: 'center', marginTop: '50px'}} >
                        <div style={{display: 'flex', alignItems: 'center', marginTop: '-40px', marginLeft: '10px'}} >
                            <div style={{textAlign: 'left'}} >
                                <H6 style={{fontWeight: 'bold'}} >Change Password</H6>
                                <P style={{fontSize: '8px'}} >Reset password for security purposes.</P>
                            </div>
                        </div>
                        <div style={{marginTop: '-80px', marginLeft: '38px'}} >
                            <Link to='/forgotPassword' >
                                <button style={{border: '1px solid #ccc', padding: '2px 10px', borderRadius: '5px', fontWeight: 'bold'}} >Reset Password</button>
                            </Link>
                            <input 
                            ref = {el => {
                                this.refInput = el
                            }}
                            accept = 'image/*'
                            type ='file'
                            className={classes.input}
                            onChange={this.handleImageChange}
                            />
                        </div>
                       </div>

                       <div style={{marginTop: '20px'}} >
                           <div><Title style={{fontWeight: 'bold'}} >My Profile</Title></div>
                        
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px',}} label='Username' type='text' name='name' value={name ? name : ''} onChange={this.handleInputChange} />
                        <TextField fullWidth variant='outlined' style={{padding: '10px', marginBottom: '20px'}} label='Full Name' type='text' name='name' value={name ? name +' '+ lastName : ''} onChange={this.handleInputChange} />
                        <TextField fullWidth multiline rows={4} variant='outlined' style={{padding: '10px', marginBottom: '20px'}} label='Tell us about yourself...' type='text' name='aboutMe' value={aboutMe ? aboutMe : ''} onChange={this.handleInputChange} />
                        {message && <p style={{color: '#013972', textAlign: 'center'}} >{message}</p>}
                        {loading ?
                            <Button variant='contained' style={{color: 'white', fontWeight: 'bold', fontFamily: 'Montserrat', backgroundColor: '#002447'}} >
                                <CircularProgress className={classes.loading} />
                            </Button>
                            :
                            <Button variant='contained' style={{color: 'white', fontWeight: 'bold', fontFamily: 'Montserrat', backgroundColor: '#002447'}} onClick={this.uploadImage}>
                            Save
                            </Button>    
                        }
                       </div>
                    
                   </div>
               </div>

                </div>
            </Root>
            </Hidden>
            // </ThemeProvider>
        )
    }
}

export default withStyles(styles)(AccountMobile);
