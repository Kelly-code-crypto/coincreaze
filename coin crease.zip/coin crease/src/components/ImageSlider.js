import React, {useState} from 'react';
import Carousel from 'react-bootstrap/Carousel';
import {makeStyles} from '@material-ui/core';

import './imageSlider.css'

const useStyles = makeStyles({
    carousel: {
        marginBottom: '20px'
    },
    img: {
        height: '600px'
    },
    caption: {
        color: 'white',
        textAlign: 'left',
        marginTop: '0px',
        position: 'relative',
        margin: '0px auto',
        width: '300px',
        marginLeft: '-20px',
        '& h3': {
            fontSize: '20px',
        },
        '& p': {
            marginTop: '30px',
            fontSize: '15px',
        }
    },
    overlay: {
        backgroundColor:'rgba(0, 0, 0, 0.5)',
        height: '100%',
        width: '100%',
        position: 'absolute',
        top: 0,
        left: 0
    },
    CarouselForm: {
        backgroundColor: 'white',
        padding: '30px',
        position: 'absolute',
        right: '6em',
        top: '50%',
        zIndex: '10',
        textAlign: 'center'
    }
});

function ImageSlider() {
    const classes = useStyles();
    const [startDate, setStartDate] = useState(null);
    return (
        <div className={classes.carousel} >
            <Carousel fade controls={false} touch={false}>
                <Carousel.Item>
                    <img
                    className="d-block w-100"
                    src="img2.jpg"
                    alt="Second slide"
                    />

                    <div className={classes.overlay} >
                        <Carousel.Caption className={classes.caption} >
                        <p >
                        3 investment rules that Warren Buffet thinks everyone should know.</p>

                        <button className='btnCarousel' >Discover More</button>
                        </Carousel.Caption>
                    </div>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                    className="d-block w-100"
                    src="img3.jpg"
                    alt="Third slide"
                    />

                    <div className={classes.overlay} >
                        <Carousel.Caption className={classes.caption} >
                        
                        <p >
                        3 ways you can net an extra $250 each month.</p>

                        <button className='btnCarousel' >Discover More</button>
                        </Carousel.Caption>
                    </div>
                </Carousel.Item>
            </Carousel>

        </div>
    )
}

export default ImageSlider
