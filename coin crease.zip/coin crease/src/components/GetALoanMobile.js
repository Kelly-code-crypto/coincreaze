import { Hidden, makeStyles } from '@material-ui/core'
import React, { useEffect } from 'react';
import Header from './Header';
import {Link} from 'react-router-dom';
import Aos from 'aos';
import 'aos/dist/aos.css';

const useStyles = makeStyles({
    hero: {
        height: '100vh',
        backgroundImage: 'url("Coincrease Loan.jpg")',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
    },
    overlay: {
        position: 'absolute',
        top: '0',
        left: '0',
        height: '100vh',
        width: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center'
    },
    qualifyBtn: {
        border: 'none',
        padding: '10px 25px',
        borderRadius: '5px',
        fontWeight: 'bold',
        backgroundColor: '#00264C',
        color: '#ccc'
    },
    applyBtn: {
        border: 'none',
        padding: '10px 25px',
        borderRadius: '5px',
        fontWeight: 'bold',
        backgroundColor: '#F6CD2D'
    }
});

function GetALoanMobile() {
    const classes = useStyles();

    useEffect(() => {
        Aos.init({
            duration: 1000
        })
    })
    return (
        <Hidden mdUp>
            <Header />
            <div className={classes.hero} >
                <div className={classes.overlay} >
                    <div style={{marginTop: '130px'}} >
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <h3 data-aos='zoom-in-left' style={{color: 'white', width: '250px'}} >New and Used Auto-Financing</h3>
                        </div>
                        <div>
                        <h4 data-aos='zoom-in-right' style={{color: 'white', width: '300px', marginTop: '50px'}} >See If You Pre-qualify With No Impact To Your Credit Score</h4>
                        </div>
                        <div style={{marginTop: '70px'}} >
                            <div>
                            <Link to='/get-qualified' >
                            <button data-aos='zoom-in' className={classes.qualifyBtn} >
                                Get Pre-qualified
                            </button>
                            </Link>
                            </div>
                            <div style={{marginTop: '20px'}} >
                            <Link to='/apply-now' >
                            <button className={classes.applyBtn} >
                                Apply Now
                            </button>
                            </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Hidden >
    )
}

export default GetALoanMobile
