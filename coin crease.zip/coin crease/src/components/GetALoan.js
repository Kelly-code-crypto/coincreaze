import React from 'react';
import { Hidden } from '@material-ui/core';
import {Link} from 'react-router-dom'
import GetALoanMobile from './GetALoanMobile';

function GetALoan() {
    return (
        <>
            <Hidden smDown>
            <Link to='/' ><h3>Coincrease</h3></Link>
            <h5>Loan With Coincrease</h5>
            </Hidden>
            
            <Hidden mdUp>
            <GetALoanMobile />
            </Hidden>
        </>
    )
}

export default GetALoan
