import { Avatar, Hidden, makeStyles } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import Header from './Header';
import Aos from 'aos';
import 'aos/dist/aos.css';
import LockOpenOutlinedIcon from '@material-ui/icons/LockOpenOutlined';
import AirplanemodeActiveOutlinedIcon from '@material-ui/icons/AirplanemodeActiveOutlined';
import ThumbUpOutlinedIcon from '@material-ui/icons/ThumbUpOutlined';
import LocalAtmOutlinedIcon from '@material-ui/icons/LocalAtmOutlined';
import { useAuth } from '../context/AuthContext';
import AccountBoxOutlinedIcon from '@material-ui/icons/AccountBoxOutlined';
import AccountBalanceOutlinedIcon from '@material-ui/icons/AccountBalanceOutlined';
import MonetizationOnOutlinedIcon from '@material-ui/icons/MonetizationOnOutlined';
import AccountBalanceWalletOutlinedIcon from '@material-ui/icons/AccountBalanceWalletOutlined';
// import Chart from './Chart';
import Calculator from './Calculator';
import StringData from '../context/StringData'
import { Link } from 'react-router-dom';
import FooterMobile from './FooterMobile';
import PriceTracker from './PriceTracker';
import Chatbot from 'react-chatbot-kit';
import ForumIcon from '@material-ui/icons/Forum';
import ForumTwoToneIcon from '@material-ui/icons/ForumTwoTone';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import config from '../Chatbot/Config';
import ActionProvider from '../Chatbot/ActionProvider';
import MessageParser from '../Chatbot/MessageParser';
import ImageSlider from './ImageSlider';



const useStyles = makeStyles({
    hero: {
        backgroundImage: 'url("image5.jpg")',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        width: '100%',
        paddingBottom: '20px'
    },
    heroContent: {
        paddingTop: '100px',
        textAlign: 'center'
    },
    heroText: {
        display: 'flex',
        justifyContent: 'center'
    },
    heroBtnOne: {
        border: 'none', 
        outline: 'none',
        padding: '10px 15px',
        borderRadius: '30px',
        backgroundColor: '#F6CD2D',
        color: 'white',
        fontWeight: 'bold',
        transition: '.5s',
        fontSize: '10px',
        '&:hover': {
            backgroundColor: '#00264C'
        }
    },
    heroBtnTwo: {
        border: '2px solid white', 
        outline: 'none',
        padding: '10px 15px',
        borderRadius: '30px',
        backgroundColor: 'transparent',
        color: 'white',
        fontWeight: 'bold',
        transition: '.5s',
        fontSize: '10px',
        margin: '20px auto',
        '&:hover': {
            color: '#F6CD2D',
            borderColor: '#F6CD2D',
        }
    },
    heroImage: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    heroPhoneImage: {
         
        zIndex: '1',
        transition: '5s',
        right: '0',
        marginTop: '20px',
        width: '100px',
        maxWidth: '100px',
    },
    phoneImageScroll: {
        
        zIndex: '1',
        marginTop: '100px',
        transition: '5s',
        width: '100px',
        maxWidth: '100px',
    },
    belowHero: {
        paddingBottom: '50px'
    },
    benefitBox: {
        padding: '20px 30px',
        transition: '.5s',
        borderRadius: '10px',
        margin: '30px',
        '&:hover': {
            boxShadow: '0 8px 15px 2px #ccc',
            cursor: 'pointer',
            '& span': {
                backgroundColor: 'rgb(199, 199, 199)'
            }
        }
    },
    portfolio: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: '40px'
    },
    updates: {
        display: 'flex',
        justifyContent: 'center',
        backgroundColor: '#06498B',
        padding: '50px 0px'
    },
    getStartedSect: {
        display: 'flex', 
        justifyContent: 'center',
        marginTop: '50px'
    },
    body: {
        paddingBottom: '40px'
    },
    // overlay: {
    //     position: 'absolute',
    //     top: '0',
    //     left: '0',
    //     backgroundColor: 'rgba(0, 0, 0, 0.356)',
    //     height: '100vh',
    //     width: '100%'
    // }
    slider: {
        margin: '0px auto',
        transition: '.5s',
        padding: '20px 50px',
        marginTop: '50px'
    },
    mainSlides: {
        margin: '0px auto',
        width: '100%',
        marginTop: '20px'
    },
});


function LandingMobile() {
    const classes = useStyles();
    const { currentUser, signOut } = useAuth();
    const Name = localStorage.getItem(StringData.FirstName);
    const [showBot, toggleBot] = useState(false);

    useEffect(() => {
        Aos.init({
            duration: 1000,
        })
    })

    const handleBotToggle = () => {
        toggleBot((prev) => !prev)
    }


    const SampleNextArrow = (props) => {
        const { className, style, onClick } = props;
            return (
                <div
                className={className}
                style={{ ...style, display: "block", background: "black" }}
                onClick={onClick}
              />
            )
           
        }
       
    
        const SamplePrevArrow = (props) => {
        const { className, style, onClick } = props;
        return (
            <div
            className={className}
            style={{ ...style, display: "block", background: "black",}}
            onClick={onClick}
            />
        )
        }
    
        const settings = {
            dots: false,
            infinite: true,
            speed: 1000,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            arrows: true,
            nextArrow: <SampleNextArrow  />,
            prevArrow: <SamplePrevArrow />
        }

    return (
        <div>
            <Hidden mdUp>
            <div style={{position: 'fixed', top: '5em', right: '2em', maxWidth: '300px', zIndex: '100',}} >
                {showBot && (
                    <Chatbot config={config} actionProvider={ActionProvider} messageParser={MessageParser}  />
                )}
            </div>
            <div style={{position: 'fixed', top: '30em', right: '1em', zIndex: '100'}} onClick={handleBotToggle} >
                {showBot ? (
                    <Avatar src='cancel.png' style={{width: '40px', height: '40px', }}   />
                ) : (
                    <Avatar src='chatbot.png' style={{width: '70px', height: '70px', }}   />
                )}
            </div>
            <Header user={currentUser} signOut={signOut} />
                {Name ? <>
                    <div className={classes.body} >
                        <div className={classes.overlay} >
                            <PriceTracker />

                            <div style={{marginTop: '50px'}} ><h4 style={{textAlign: 'center', fontWeight: 'bold'}} >Dashboard</h4></div>
                            <div style={{padding: '0px 20px', marginTop: '50px'}} >
                                <div style={{display: 'flex', justifyContent: 'space-between', backgroundColor: 'white', padding: '10px', boxShadow: '0 0 10px 1px #ccc', borderRadius: '5px'}} >
                                    <h4 style={{color: '#06498B', fontWeight: 'bold'}} >Deposit Wallet <br /><span style={{fontSize: '20px', color: 'green'}} >$0</span></h4>
                                    <AccountBalanceWalletOutlinedIcon style={{fontSize: '50px', color: '#F6CD2D'}} />
                                </div>
                            </div>
                            <div style={{padding: '0px 20px', marginTop: '50px'}} >
                                <div style={{display: 'flex', justifyContent: 'space-between', backgroundColor: 'white', padding: '10px', boxShadow: '0 0 10px 1px #ccc', borderRadius: '5px'}} >
                                    <h4 style={{color: '#06498B', fontWeight: 'bold'}} >Interest Wallet <br /><span style={{fontSize: '20px', color: 'green'}} >$0</span></h4>
                                    <AccountBalanceWalletOutlinedIcon style={{fontSize: '50px', color: '#F6CD2D'}} />
                                </div>
                            </div>
                            <div style={{padding: '0px 20px', marginTop: '50px'}} >
                                <div style={{display: 'flex', justifyContent: 'space-between', backgroundColor: 'white', padding: '10px', boxShadow: '0 0 10px 1px #ccc', borderRadius: '5px'}} >
                                    <h4 style={{color: '#06498B', fontWeight: 'bold'}} >Total Investment <br /><span style={{fontSize: '20px', color: 'green'}} >$0</span></h4>
                                    <AccountBalanceWalletOutlinedIcon style={{fontSize: '50px', color: '#F6CD2D'}} />
                                </div>
                            </div>
                            <div style={{padding: '0px 20px', marginTop: '50px'}} >
                                <div style={{display: 'flex', justifyContent: 'space-between', backgroundColor: 'white', padding: '10px', boxShadow: '0 0 10px 1px #ccc', borderRadius: '5px'}} >
                                    <h4 style={{color: '#06498B', fontWeight: 'bold'}} >Total Withdraw <br /><span style={{fontSize: '20px', color: 'green'}} >$0</span></h4>
                                    <AccountBalanceWalletOutlinedIcon style={{fontSize: '50px', color: '#F6CD2D'}} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <FooterMobile />
                </> : 
                
                <>
                <div className={classes.hero} >
                    <div className={classes.heroContent} >
                    <div className={classes.heroText} >
                        <div style={{textAlign: 'center'}} data-aos='zoom-in-right' >
                            <h1 style={{fontFamily: 'Montserrat', fontWeight: 'bolder', fontSize: '40px', width: '200', color: 'white', marginTop: '80px', marginBottom: '50px'}} >Secure and Anonymous Cryptocurrency</h1>
                            <p style={{color: 'rgb(196, 196, 196)', width: '90%', fontWeight: 'bold', margin: '0px auto'}}>
                                Coincreaze is an investment platform,
                                made to be easily used by everyone.
                            </p>
                            <div style={{display: 'flex', alignItems: 'center', marginTop: '30px', padding: '0px 10px', justifyContent: 'center'}} >
                                <Link to='/signin' >
                                    <button className={classes.heroBtnTwo} >
                                        Get Started with Coincreaze
                                    </button>
                                </Link>
                            </div>

                        <div className={classes.heroImage} >
                            <img style={{width: '300px', marginTop: '50px'}} src="image4.png" alt=""/>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                <div className={classes.portfolio} >
                    <div style={{width: '300px', marginTop: '50px'}} >
                    <h3 style={{fontWeight: 'bold', width: '300px', color: '#06498B'}} >Jump start your crypto Porfolio</h3>
                    <p>Coincreaze is the easiest place to invest your Cryptocurrencies. Sign Up and get started today.</p>
                    <input style={{padding: '10px 20px'}}  type="text" placeholder='Email Address'  />
                    <Link to='/signin' >
                    <button style={{padding: '10px 80px', marginTop: '5px', border: '1px solid #ccc', fontWeight: 'bold', borderRadius: '5px', backgroundColor: '#02376D', color: 'white'}} >Get Started</button>
                    </Link>
                    </div>
                </div>

                {/* <div style={{backgroundColor: '#01366A', padding: '30px 0px', marginTop: '50px'}} >
                    <Calculator />
                </div> */}

                <div style={{padding: '0px 20px', display: 'flex', justifyContent: 'center', margin: '50px auto', marginTop: '70px'}} >
                    <div>
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                            <Avatar style={{width: '200px', height: '200px'}} src='security.svg' variant='circular' alt='security img' />
                        </div>
                        <div style={{textAlign: 'center'}} >
                            <h5 style={{fontWeight: 'bold', marginTop: '20px', color: '#06498B'}} >Security that's has strong as an oak</h5>
                            <p style={{fontSize: '15px'}} >We use bank-level security, 256-bit encryption, and allow two-factor authentication for added security.</p>
                        </div>
                    </div>
                </div>

                <div style={{display: 'flex', justifyContent: 'center', marginTop: '50px', margin: '100px 0px'}} >
                    <div style={{textAlign: 'center'}} >
                        <h4 style={{fontWeight: 'bold', color: '#06498B'}} >Earn up to $50 in free BTC </h4>
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                        <p style={{color: 'rgb(119, 119, 119)', width: '300px'}} >Discover how specific Cryptocurrencies work - and get a bit of each crypto to try out for yourself.</p>
                        </div>
                        <Link to='/signin' >
                        <button style={{padding: '10px 80px', marginTop: '5px', border: '1px solid #ccc', fontWeight: 'bold', borderRadius: '5px', backgroundColor: '#02376D', color: 'white'}} >Start Earning</button>
                        </Link>
                    </div>
                </div>

                <ImageSlider />

                <div style={{width: '100%', height: '1px', backgroundColor: '#ccc'}} ></div>

                <div className={classes.belowHero} >
                    <div style={{display: 'flex', justifyContent: 'center', marginTop: '50px'}} >
                        <img style={{width: '250px', height: '250px'}} src="image.png" alt=""/>
                    </div>

                    <div style={{display: 'flex', justifyContent: 'center', }}>
                      <div style={{width: '250px'}} >
                        <h3 style={{fontSize: '30px', fontWeight: 'bolder', color: '#012241', textAlign: 'center', marginTop: '30px'}}>The Most Trusted Cryptocurrency Platform</h3>

                            <p style={{marginTop: '30px', fontSize: '15px', color: 'rgb(148, 148, 148)', textAlign: 'center'}} >Here are few reasons why you should choose Coincreaze</p>
                      </div>
                    </div>

                    <div style={{padding: '10px 50px', marginTop: '30px'}} >
                        <div data-aos='zoom-in-up' className={classes.benefitBox} >
                            <span style={{textAlign: 'left', padding: '10px', width: '100px', borderBottomRightRadius: '20px', transition: '.5s'}} >01.</span>
                            <div  style={{textAlign: 'center'}}><LockOpenOutlinedIcon  style={{fontSize: '70px', color: '#F7CD2D'}} /></div>
                            <h3 style={{textAlign: 'center', marginTop: '20px', fontWeight: 'bold', color: '#012241'}}>Privacy</h3>
                            <p style={{textAlign: 'center', width: '150px', fontSize: '15px', color: 'rgb(148, 148, 148)'}} >Assured Privacy and
                            Anonymity</p>
                        </div>
                        <div data-aos='zoom-in-up' className={classes.benefitBox} >
                            <span style={{textAlign: 'left', padding: '10px', width: '100px', borderBottomRightRadius: '20px', transition: '.5s'}} >02.</span>
                            <div  style={{textAlign: 'center'}}><AirplanemodeActiveOutlinedIcon  style={{fontSize: '70px', color: '#F7CD2D'}} /></div>
                            <h3 style={{textAlign: 'center', marginTop: '20px', fontWeight: 'bold', color: '#012241'}}>Speed</h3>
                            <p style={{textAlign: 'center', width: '155px', fontSize: '15px', color: 'rgb(148, 148, 148)'}} >Instant, on-demand
                            settlement</p>
                        </div>
                        <div data-aos='zoom-in-up' className={classes.benefitBox} >
                            <span style={{textAlign: 'left', padding: '10px', width: '100px', borderBottomRightRadius: '20px', transition: '.5s'}} >03.</span>
                            <div  style={{textAlign: 'center'}}><ThumbUpOutlinedIcon  style={{fontSize: '70px', color: '#F7CD2D'}} /></div>
                            <h3 style={{textAlign: 'center', marginTop: '20px', fontWeight: 'bold', color: '#012241'}}>Certainty</h3>
                            <p style={{textAlign: 'center', width: '150px', fontSize: '15px', color: 'rgb(148, 148, 148)'}} >Real-time traceability
                            of funds</p>
                        </div>
                        <div data-aos='zoom-in-up' className={classes.benefitBox} >
                            <span style={{textAlign: 'left', padding: '10px', width: '100px', borderBottomRightRadius: '20px', transition: '.5s'}} >04.</span>
                            <div  style={{textAlign: 'center'}}><LocalAtmOutlinedIcon  style={{fontSize: '70px', color: '#F7CD2D'}} /></div>
                            <h3 style={{textAlign: 'center', marginTop: '20px', fontWeight: 'bold', color: '#012241'}}>Cost</h3>
                            <p style={{textAlign: 'center', width: '150px', fontSize: '15px', color: 'rgb(148, 148, 148)'}} >Low operational and
                            liquidity costs</p>
                        </div>
                    </div>

                </div>

                <div className={classes.updates} >
                    <div style={{textAlign: 'center'}} >
                        <div>
                        <h4 style={{fontSize: '40px', fontWeight: 'bold', color: 'white'}} >$335B</h4>
                        <p style={{color: '#ccc'}} >Quarterly volume traded</p>
                        </div>
                        <div>
                        <h4 style={{fontSize: '40px', fontWeight: 'bold', color: 'white'}} >100+</h4>
                        <p style={{color: '#ccc'}} >Country Supported</p>
                        </div>
                        <div>
                        <h4 style={{fontSize: '40px', fontWeight: 'bold', color: 'white'}} >56+M</h4>
                        <p style={{color: '#ccc'}} >Verified Users</p>
                        </div>
                    </div>
                </div>

                <div style={{display: 'flex', justifyContent: 'center', textAlign: 'center', marginTop: '50px'}} >
                    <div>
                    <h5 style={{fontWeight: 'bold', color: '#06498B'}} >Earn More Money</h5>
                    <p style={{width: '300px', margin: '0px auto', }} >From 350+ brands that invest in you, to millions of jobs searchable right from your Coincreaze app, and more. Earn more, so you can save and invest more.</p>
                    </div>
                </div>

                <div  className={classes.slider} >
                <div style={{textAlign: 'center'}} >
                    <h3 style={{marginBottom: '30px', fontWeight: 'bold', color: '#00264C' }} >What Customers Say</h3>
                </div>
                <Slider className={classes.mainSlides} {...settings}>
                    <div>
                   <div style={{display: 'flex', justifyContent: 'center'}} > <Avatar style={{width: '70px', height: '70px'}} variant='circular' src='user1.jpg' /></div>
                        <p style={{textAlign: 'center', marginTop: '20px' }}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi magni repellat a vero facere impedit voluptates in delectus.</p>
                        <div style={{display: 'flex', justifyContent: 'center'}} ><p> - Adam Koo</p></div>
                    </div>
                    <div >
                    <div style={{display: 'flex', justifyContent: 'center'}} > <Avatar style={{width: '70px', height: '70px'}} variant='circular' src='user2.jpg' /></div>
                        <p style={{textAlign: 'center', marginTop: '20px' }}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi magni repellat a vero facere impedit voluptates in delectus.</p>
                        <div style={{display: 'flex', justifyContent: 'center'}} ><p> - Miranda Gabriels</p></div>
                    </div>
                    <div >
                    <div style={{display: 'flex', justifyContent: 'center'}} > <Avatar style={{width: '70px', height: '70px'}} variant='circular' src='user3.png' /></div>
                        <p style={{textAlign: 'center', marginTop: '20px' }}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi magni repellat a vero facere impedit voluptates in delectus.</p>
                        <div style={{display: 'flex', justifyContent: 'center'}} ><p> - Kate Curtis</p></div>
                    </div>
                </Slider >
            </div>

                <div className={classes.getStartedSect} >
                    <div>
                        <div>
                            <h3 style={{fontSize: '30px', fontWeight: 'bolder', color: '#012241', textAlign: 'center', marginTop: '50px'}}>Get Started with Few Steps</h3>
                            <p style={{marginTop: '30px', fontSize: '15px', color: 'rgb(148, 148, 148)', textAlign: 'center', padding: '0px 2px'}} >Coincreaze supports a variety of the most popular digital currencies.</p>
                        </div>

                        <div>
                            <div data-aos='zoom-in-up' style={{textAlign: 'center', margin: '40px auto'}} >
                                <AccountBoxOutlinedIcon style={{fontSize: '70px', color: '#06498B'}} />
                                <h6>Create an Account</h6>
                            </div>
                            <div data-aos='zoom-in-up' style={{textAlign: 'center', margin: '40px auto'}} >
                                <AccountBalanceOutlinedIcon style={{fontSize: '70px', color: '#06498B'}} />
                                <h6>Link Your Bank Account</h6>
                            </div>
                            <div data-aos='zoom-in-up' style={{textAlign: 'center', margin: '40px auto'}} >
                                <MonetizationOnOutlinedIcon style={{fontSize: '70px', color: '#06498B'}} />
                                <h6>Start Investing </h6>
                            </div>
                        </div>
                    </div>
                </div>

                <div style={{marginTop: '40px'}} >
                <FooterMobile />
                </div>
                </>
                }
            </Hidden>
        </div>
    )
}

export default LandingMobile;
