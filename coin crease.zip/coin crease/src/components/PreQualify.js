import React from 'react';
import { Link } from 'react-router-dom';
import StringData from '../context/StringData'


function PreQualify() {
    const firstName = localStorage.getItem(StringData.firstName)
    const MI = localStorage.getItem(StringData.MI)
    const lastName = localStorage.getItem(StringData.lastName)
    const ssn = localStorage.getItem(StringData.ssn)
    const residentialAddress = localStorage.getItem(StringData.residentialAddress)
    const aptSuite = localStorage.getItem(StringData.aptSuite)
    const emailAddress = localStorage.getItem(StringData.emailAddress)
    const phoneNumber = localStorage.getItem(StringData.phoneNumber)
    const annualIncome = localStorage.getItem(StringData.annualIncome)
    const monthlyIncome = localStorage.getItem(StringData.monthlyIncome)
    const DOB = localStorage.getItem(StringData.DOB)
    const checking = localStorage.getItem(StringData.checking)
    const employed = localStorage.getItem(StringData.employed)
    return (
        <div>
            <div style={{}} >
                <div style={{padding: '0px 0px', marginTop: '30px'}} >
                <h5 style={{textAlign: 'center', fontWeight: 'bold', color: '#013972'}} >Here are your pre-qualification details.</h5>
                </div>

                <div style={{backgroundColor: 'white', padding: '20px', marginTop: '40px'}} >
                    <p>First Name : {firstName}</p>
                    <p>Last Name : {lastName}</p>
                    <p>MI : {MI}</p>
                    <p>DOB : {DOB}</p>
                    <p>SSN : {ssn}</p>
                    <p>Residential Address : {residentialAddress}</p>
                    <p>Apt/Suite : {aptSuite}</p>
                    <p>Email Address : {emailAddress}</p>
                    <p>Phone Number : {phoneNumber}</p>
                    <p>Annual Income/Year : ${annualIncome}</p>
                    <p>Monthly Income : ${monthlyIncome}</p>
                    <p>Bank Type : {checking}</p>
                    <p>Employment Status : {employed}</p>
                </div>

                <div style={{display: 'flex', justifyContent: 'center', margin: '5px auto', marginTop: '15px', marginBottom: '50px'}} >
                <div style={{marginLeft: '35px'}} >
                <Link to='/qualify-success' >
                <button style={{marginTop: '20px', fontWeight: 'bold', border: 'none', padding: '10px 20px', width: '300px', backgroundColor: '#013972', borderRadius: '5px', color: 'white' }} >Continue</button>
                </Link>
                <Link to='/get-qualified' >
                <button style={{marginTop: '20px', fontWeight: 'bold', border: 'none', padding: '10px 20px', width: '300px', backgroundColor: '#F6CD2D', borderRadius: '5px', color: 'white' }} >Back</button>
                </Link>
                </div>
                </div>
            </div>
        </div>
    )
}

export default PreQualify
