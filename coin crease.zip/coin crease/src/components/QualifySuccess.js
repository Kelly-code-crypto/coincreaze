import React from 'react';
import CheckCircleOutlineOutlinedIcon from '@material-ui/icons/CheckCircleOutlineOutlined';
import { Link } from 'react-router-dom';
import {makeStyles} from '@material-ui/core';
import StringData from '../context/StringData'

const useStyles = makeStyles({
    applyBtn: {
        border: 'none',
        padding: '10px 25px',
        borderRadius: '5px',
        fontWeight: 'bold',
        backgroundColor: '#003970',
        color: 'white'
    }
});

function QualifySuccess() {
    const classes = useStyles();
    const Name = localStorage.getItem(StringData.FirstName);
    return (
        <div style={{display: 'flex', justifyContent: 'center'}} >
            <div style={{marginTop: '100px', textAlign: 'center'}} >
                <div><CheckCircleOutlineOutlinedIcon style={{color: 'green', fontSize: '50px', textAlign: 'center'}} /></div>
                <p>Success! {Name}, You have been approved!</p>
                <p>Thanks for applying for Coincrease Loan!<br/>So what's next?</p>

                <div>
                    <Link to='/apply-now' >
                        <button className={classes.applyBtn} >
                            Apply Now
                        </button>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default QualifySuccess
