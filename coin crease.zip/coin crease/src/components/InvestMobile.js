import { Hidden, makeStyles } from '@material-ui/core';
import React from 'react';
// import {useAuth} from '../context/AuthContext';
import StringData from '../context/StringData';
import {Link} from 'react-router-dom';
import Header from './Header';
import Checkout from './Checkout';

import CoinbaseCommerceButton from 'react-coinbase-commerce';
import 'react-coinbase-commerce/dist/coinbase-commerce-button.css';

import {CardElement, useStripe, useElements} from '@stripe/react-stripe-js'

const useStyles = makeStyles({
    innerTierBoxSm: {
        width: '300px',
        height: '400px',
        boxShadow: '0 0 10px 3px rgb(156, 156, 156)',
        borderRadius: '20px',
        color: 'white',
        backgroundColor: '#004388',
        textAlign: 'center',
        margin: '10px auto',
        marginTop: '30px'
      },
      investBtn: {
          border: 'none',
          padding: '5px 40px',
          marginTop: '30px',
          backgroundColor: '#F6CD2D',
          color: '#00264C',
          fontWeight: 'bold'
      }
});

function InvestMobile() {
    const classes = useStyles();
    // const {currentUser} = useAuth();
    const Name = localStorage.getItem(StringData.FirstName)

    // const stripe = useStripe();
    // const elements = useElements()

    return (
        <Hidden mdUp>
            <Header />
           <div style={{paddingTop: '100px'}} >
               <div style={{display: 'flex', justifyContent: 'center', textAlign: 'center', marginTop: '30px'}} >
                    <div>
                        <h4 style={{fontWeight: 'bold', color: '#06498B'}} >Simple, transparent plans</h4>
                        <p style={{width: '300px'}} >Rather than surprise fees, we bundle our products into subscription tiers that support your financial wellness.</p>
                    </div>
               </div>
                <div className={classes.innerTierBoxSm} >
                    <div>
                    <h2 style={{color: '#F2B28E', fontSize: '30px', paddingTop: '15px'}} >Bronze</h2>
                    <p style={{fontSize: '10px', marginTop: '10px' }} >Staking Requirements</p>
                    <h3 style={{marginTop: '30px', fontSize: '35px', backgroundColor: '#F6CD2D', color: '#00264C' }} >10,000 <span style={{fontSize: '20px', }}>Ceriums</span><br /> <span style={{fontSize: '10px', }} >for 7 days</span> </h3>
                    <p style={{marginTop: '30px', fontWeight: 'bold', }} >Guaranteed Allocation</p>
                    <p style={{marginTop: '10px', fontWeight: 'bold', }}>Yes</p>
                    <CoinbaseCommerceButton onChargeSuccess={(MessageData) => console.log('Suucess!!', MessageData)} onLoad={() => console.log("Modal Loading!")} onModalClosed={() => console.log("Modal Closed!")} checkoutId={'b8b29c5f-086a-4654-b090-17db8a8d902d'}
                    style={{backgroundColor: '#F6CD2D', padding: '10px 20px', border: 'none', borderRadius: '5px'}}
                    >
                        Invest Now Using Crypto
                    </CoinbaseCommerceButton>
                    </div>
                </div>
                <div className={classes.innerTierBoxSm} >
                    <div>
                    <h2 style={{color: '#BABABA', fontSize: '30px', paddingTop: '15px'}} >Silver</h2>
                    <p style={{fontSize: '10px', marginTop: '10px' }} >Staking Requirements</p>
                    <h3 style={{marginTop: '30px', fontSize: '35px', backgroundColor: '#F6CD2D', color: '#00264C' }} >10,000 <span style={{fontSize: '20px', }}>Ceriums</span><br /> <span style={{fontSize: '10px', }} >for 7 days</span> </h3>
                    <p style={{marginTop: '30px', fontWeight: 'bold', }} >Guaranteed Allocation</p>
                    <p style={{marginTop: '10px', fontWeight: 'bold', }}>Yes</p>
                    <CoinbaseCommerceButton onChargeSuccess={(MessageData) => console.log('Suucess!!', MessageData)} onLoad={() => console.log("Modal Loading!")} onModalClosed={() => console.log("Modal Closed!")} checkoutId={'75e51715-18df-41ef-b1ea-14e6713d6615'} style={{backgroundColor: '#F6CD2D', padding: '10px 20px', border: 'none', borderRadius: '5px'}}
                    >
                        Invest Now Using Crypto
                    </CoinbaseCommerceButton>
                    <Link to='/checkout' >
                        <button>
                            Pay with card
                        </button>
                    </Link>
                    </div>
                </div>
                <div className={classes.innerTierBoxSm} >
                    <div>
                    <h2 style={{color: '#C99404', fontSize: '30px', paddingTop: '15px'}} >Gold</h2>
                    <p style={{fontSize: '10px', marginTop: '10px' }} >Staking Requirements</p>
                    <h3 style={{marginTop: '30px', fontSize: '35px', backgroundColor: '#F6CD2D', color: '#00264C' }} >10,000 <span style={{fontSize: '20px', }}>Ceriums</span><br /> <span style={{fontSize: '10px', }} >for 7 days</span> </h3>
                    <p style={{marginTop: '30px', fontWeight: 'bold', }} >Guaranteed Allocation</p>
                    <p style={{marginTop: '10px', fontWeight: 'bold', }}>Yes</p>
                    <CoinbaseCommerceButton onChargeSuccess={(MessageData) => console.log('Suucess!!', MessageData)} onLoad={() => console.log("Modal Loading!")} onModalClosed={() => console.log("Modal Closed!")} checkoutId={'e714da58-d90d-444b-a33f-8185546db417'} style={{backgroundColor: '#F6CD2D', padding: '10px 20px', border: 'none', borderRadius: '5px'}}
                    >
                        Invest Now Using Crypto
                    </CoinbaseCommerceButton>
                    </div>
                </div>
           </div>
        </Hidden>
    )
}

export default InvestMobile
