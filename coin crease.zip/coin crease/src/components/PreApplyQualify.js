import { Avatar } from '@material-ui/core';
import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import StringData from '../context/StringData'
import {db} from './firebase';

function PreApplyQualify() {
    const firstName = localStorage.getItem(StringData.ApplyFirstname)
    const MI = localStorage.getItem(StringData.ApplyMI)
    const lastName = localStorage.getItem(StringData.ApplyLastname)
    const ssn = localStorage.getItem(StringData.ApplySSN)
    const DOB = localStorage.getItem(StringData.ApplyDOB)
    const frontView = localStorage.getItem(StringData.FrontView)
    const backView = localStorage.getItem(StringData.BackView)
    const history = useHistory();

    const handleSubmit = (e) => {
        e.preventDefault();

        db.collection('Application Details').doc().set({
          FirstName: firstName,
          LastName: lastName,
          MI: MI,
          SSN: ssn,
          DOB: DOB
      })

      history.push('/application-success')
    }


    return (
        <div>
            <div style={{}} >
                <div style={{padding: '0px 0px', marginTop: '30px'}} >
                <h5 style={{textAlign: 'center', fontWeight: 'bold', color: '#013972'}} >Here are your Application details.</h5>
                </div>

                <div style={{backgroundColor: 'white', padding: '20px', marginTop: '40px'}} >
                    <p>First Name : {firstName}</p>
                    <p>Last Name : {lastName}</p>
                    <p>MI : {MI}</p>
                    <p>SSN : {ssn}</p>
                    <p>Date of Birth : {DOB}</p>
                    <p>Card Front View : <Avatar src={frontView} variant='square' style={{width: '200px', height: '100px'}} /></p>
                    <p>Card Back View : <Avatar src={backView} variant='square' style={{width: '200px', height: '100px'}} /></p>
                    
                </div>

                <div style={{display: 'flex', justifyContent: 'center', margin: '5px auto', marginTop: '15px', marginBottom: '50px'}} >
                <div style={{marginLeft: '35px'}} >
                <button onClick={handleSubmit} style={{marginTop: '20px', fontWeight: 'bold', border: 'none', padding: '10px 20px', width: '300px', backgroundColor: '#013972', borderRadius: '5px', color: 'white' }} >Continue</button>
                <Link to='/apply-now' >
                <button style={{marginTop: '20px', fontWeight: 'bold', border: 'none', padding: '10px 20px', width: '300px', backgroundColor: '#F6CD2D', borderRadius: '5px', color: 'white' }} >Back</button>
                </Link>
                </div>
                </div>
            </div>
        </div>
    )
}

export default PreApplyQualify
