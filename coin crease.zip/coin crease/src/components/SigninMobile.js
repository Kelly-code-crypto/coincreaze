import React, {useEffect, useState} from 'react';
import { CircularProgress, Divider, Hidden, makeStyles } from '@material-ui/core';
import {Link, useHistory} from 'react-router-dom';
// import HomeIcon from '@material-ui/icons/Home';
import { useAuth } from '../context/AuthContext';
import StringData from '../context/StringData'
import {db} from './firebase';

const useStyles = makeStyles({
    signIn: {
        display: 'flex',
        justifyContent: 'center',
        backgroundImage: 'url("image5.jpg")' ,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        paddingTop: '50px'
    },
    signBox: {
        padding: '20px 50px',
        backgroundColor: 'transparent',
        '& form': {
            marginTop: '20px',
            marginBottom: '50px'
        }
    },
    label: {
        marginTop: '20px',
        fontSize: '15px',
        fontWeight: 'bold',
        color: '#F6CD2D'
    },
    input: {
        borderRadius: '5px',
        margin: '0px auto',
        width: '260px',
        outline: 'none',
        border: 'none',
        transition: '.1s',
        padding: '10px 20px',
        position: 'relative',
        backgroundColor: 'rgba(207, 207, 207, 0.336)',
        color: 'white',
        '&:focus': {
            backgroundColor: 'rgba(207, 207, 207, 0.562)'
        }
    },
    signBtn: {
        border: 'none', 
        outline: 'none',
        padding: '10px 100px',
        borderRadius: '30px',
        backgroundColor: '#F6CD2D',
        color: 'white',
        fontWeight: 'bold',
        transition: '.5s',
        marginTop: '20px',
        '&:hover': {
            backgroundColor: '#00264C'
        }
    },
})

function SigninMobile() {
    const classes = useStyles(); 
    const history = useHistory();
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null);
    const {signIn} = useAuth();

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true)
        setError(null)

        if(email === '' || password === ''){
            return (
                setError('No field can be empty.'),
                setLoading(false)
            )
        }else {
            signIn(email, password).then(res => {
                let user = res.user;
            if(user) {
                db.collection('users').where('id', '==', user.uid).get()
                .then((querySnapshot)=> {
                    querySnapshot.forEach(doc => {
                        const currentData = doc.data();
                        localStorage.setItem(StringData.FirebaseDocumentId, doc.id)
                        localStorage.setItem(StringData.ID, currentData.id)
                        localStorage.setItem(StringData.FirstName, currentData.firstName)
                        localStorage.setItem(StringData.LastName, currentData.lastName)
                        localStorage.setItem(StringData.Email, currentData.email)
                        localStorage.setItem(StringData.Password, currentData.password)
                        localStorage.setItem(StringData.PhotoURL, currentData.URL)
                        localStorage.setItem(StringData.Description, currentData.description)
                if(res) {
                    history.push('/')
                }
            })
        })
    }

            }).catch(err => {
                setLoading(false)
                console.error(err)
                if(err.code){
                    setError(err.message)
                }
            })
        }

        
    }

    useEffect(() => {
        if(localStorage.getItem(StringData.ID)) {
            history.push('/')
        }
    })

    return (
        <>
            <Hidden mdUp>
                <div className={classes.signIn} >
                <div className={classes.signBox} >
                    <div style={{display: 'flex', alignItems: 'center', textAlign: 'center', justifyContent: 'center' }} >
                            <img style={{width: '150px', maxWidth: '300px'}}  src='logo.png' alt=''/>
                    </div>
                    <form onSubmit={handleSubmit} action="" style={{display: 'block' }} >
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                            <div>
                            <h5 className={classes.label} >Email</h5>
                            <input onChange={(e) => setEmail(e.target.value)} type="email" placeholder='yourmail@mail.com' className={classes.input} value={email} />
                            </div>
                        </div>
                        <div style={{display: 'flex', justifyContent: 'center'}}>
                            <div>
                            <h5 className={classes.label} >Password</h5>
                            <input onChange={(e) => setPassword(e.target.value)} type="password" placeholder='123456#*^' className={classes.input} value={password} />
                            </div>
                        </div>
                        <div style={{textAlign: 'right', marginTop: '20px'}} >
                            <Link style={{textDecoration: 'none'}} to='/forgotPassword' >
                                <p style={{color: '#F6CD2D', marginRight: '10px' }} >Forgot Password?</p>
                            </Link>
                        </div>
                        <div style={{display: 'flex', justifyContent: 'center'}} >
                            {loading ? <button className={classes.signBtn} ><CircularProgress /></button> : <button disabled={loading} type='submit' className={classes.signBtn} >Sign In</button>}
                        </div>
                    </form>
                    {error != null ? <p style={{textAlign: 'center', color: 'red', fontSize: '13px', marginTop: '10px'}} >{error}</p> : null}
                    <Divider style={{marginTop: '20px'}} />
                    <div style={{display: 'flex', justifyContent: 'center', marginTop: '20px'}}>
                        <p style={{color: '#fff',}}>Do not have an account? <Link style={{color: '#F6CD2D', textDecoration: 'none'}} to="/signup">Sign up</Link></p>
                    </div>
                    <div style={{display: 'flex', justifyContent: 'center', marginTop: '20px'}}>
                        <p style={{textAlign: 'center', fontSize: '12px', color: 'rgb(165, 165, 165)'}} >Trust is Our Product™<br />
                            For trademarks and patents, please see our <Link to='/' style={{color: '#F6CD2D', textDecoration: 'none'}} >Privacy Policy</Link>.<br />
                            NMLS #1518126<br />
                            © Copyright 2021 Coincreaze Company, LLC.
                        </p>
                    </div>
                </div>
            </div>
        </Hidden>
        
        </>
    )
}

export default SigninMobile
