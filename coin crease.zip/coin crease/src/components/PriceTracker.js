import React, {useState, useEffect} from 'react';
import axios from 'axios'
import { Avatar } from '@material-ui/core';

const URL = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=5&page=1&sparkline=false'

function PriceTracker() {
    const [coins, setCoins] = useState([]);

    useEffect(() => {
        axios.get(URL).then(res => {
            setCoins(res.data);
            console.log(res.data);
        }).catch(e => {
            console.error(e)
        })
    }, [])

    return (
        <div style={{ padding: '0px 20px', paddingTop: '100px',}} >
            {coins.map(coin => (
               <>
                 <div key={coin.name} style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}} >
                    <div style={{display: 'flex', alignItems: 'center'}} ><Avatar src={coin.image} alt="" style={{width: '30px', height: '30px'}}  />
                    <h6 style={{marginTop: '10px', marginLeft: '5px'}} >{coin.name}</h6>
                    </div>
                   
                   <div style={{marginTop: '30px', textAlign: 'right'}} >
                   <p style={{marginBottom: '-2px'}} >${coin.current_price}</p>
                    {coin.price_change_percentage_24h < 0 ? 
                    (<p style={{color: 'red'}} >{coin.price_change_percentage_24h.toFixed(2)}%</p>) : (<p style={{color: 'green'}}>{coin.price_change_percentage_24h.toFixed(2)}%</p>)
                }
                   </div>
                </div>
                <div style={{height: '1px', backgroundColor: 'grey', width: '100%'}} ></div>
               </>
            ))}
        </div>
    )
}

export default PriceTracker
