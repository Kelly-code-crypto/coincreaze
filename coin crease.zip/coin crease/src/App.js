import React, { useState } from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import {ThemeProvider} from 'styled-components';
import {loadStripe} from '@stripe/stripe-js';
import {Elements} from '@stripe/react-stripe-js'

import Landing from './components/Landing';
import Signin from './components/Signin';
import Signup from './components/Signup';
import Account from './components/Account';
import Invest from './components/Invest';

import './App.css';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import ForgotPassword from './components/ForgotPassword';
import Calculator from './components/Calculator';
import EmailVerified from './components/EmailVerified';
import GetALoan from './components/GetALoan';
import GetQualified from './components/GetQualified';
import ApplyNow from './components/ApplyNow';
import Toggler from './components/Toggler';
import PreQualify from './components/PreQualify';
import QualifySuccess from './components/QualifySuccess';
import ApplySuccess from './components/ApplySuccess';
import PreApplyQualify from './components/PreApplyQualify';
import Checkout from './components/Checkout';
import GetALoanMobile from './components/GetALoanMobile';

const promise = loadStripe('pk_test_51IAxP3AdpHQkkByfLMHt6gCqoGIIGMuxeibAuUVRA8tCkG0K5EC8N2dZDXy2AbunxDvgw9A81EK8g6bUwCUvLie500MRqwQ14v')


const LightTheme = {
  backgroundColor: 'white',
  // ACCOUNTS
  headerBgColor: 'white',
  dividerColor: '#013972',
  h6Color: 'black',
  pColor: 'black',
  titleColor: 'black'
}

const DarkTheme = {
  backgroundColor: '#013972',
  // ACCOUNTS
  headerBgColor: 'black',
  dividerColor: '#F6CD2D',
  h6Color: '#F6CD2D',
  pColor: '#ccc',
  titleColor: '#ccc'
}

const themes = {
  light: LightTheme,
  dark: DarkTheme
}

function App() {
  const [theme, setTheme] = useState('light');
  return (          
    <div className="App">
      <ThemeProvider theme={themes[theme]} >
      <Router>
        <AuthProvider>
          <Switch>
                <Route exact path='/' >
                    <Landing theme={theme} setTheme={setTheme}/>
                </Route>
                <Route path='/signin' >
                    <Signin theme={theme} setTheme={setTheme}/>
                </Route>
                <Route path='/signup' >
                    <Signup theme={theme} setTheme={setTheme}/>
                </Route>
                <Route path='/forgotPassword' >
                    <ForgotPassword theme={theme} setTheme={setTheme}/>
                </Route>
                <Route path='/toggle' >
                    <Toggler theme={theme} setTheme={setTheme}/>
                </Route>
                <Route path='/email-verify' >
                    <EmailVerified theme={theme} setTheme={setTheme}/>
                </Route>
                <Elements stripe={promise} >
                <Route path='/checkout' >
                    <Checkout theme={theme} setTheme={setTheme}/>
                </Route>
                </Elements>
                <PrivateRoute path='/apply-now' component={ApplyNow} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/get-a-loan' component={GetALoan} theme={theme} setTheme={setTheme}/>
                {/* <PrivateRoute path='/get-a-loan-mobile' component={GetALoanMobile} theme={theme} setTheme={setTheme}/> */}
                <PrivateRoute path='/get-qualified' component={GetQualified} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/account' component={Account} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/invest' component={Invest} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/pre-qualify' component={PreQualify} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/qualify-success' component={QualifySuccess} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/application-success' component={ApplySuccess} theme={theme} setTheme={setTheme}/>
                <PrivateRoute path='/confirm-application-details' component={PreApplyQualify} theme={theme} setTheme={setTheme}/>
          </Switch>
        </AuthProvider>
      </Router>
      </ThemeProvider>
    </div>
  );
}

export default App;
