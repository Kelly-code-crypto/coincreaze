import { Avatar } from '@material-ui/core';
import {createChatBotMessage} from 'react-chatbot-kit';
import StringData from '../context/StringData'
import Options from './Options';

const Name = localStorage.getItem(StringData.FirstName)
const PhotoURL = localStorage.getItem(StringData.PhotoURL)

const config = {
    botName: 'Coincreaze Agent',
    initialMessages: [
        createChatBotMessage(`Hello ${Name ? Name : 'Friend'}, What would you like to know?`, {widget: 'options'})
    ],
    customStyles: {
        botMessageBox: {
          backgroundColor: "#F6CD2D",
        },
        chatButton: {
            backgroundColor: "#012241",
          },
    },
    customComponents: {
        header: () => <div style={{ backgroundColor: '#012241', padding: "5px", borderRadius: "5px", color: 'white', textAlign: 'center' }}>Coincreaze Online Agent</div>,
        userAvatar: (props) => <Avatar {...props} src={PhotoURL} />,
        botAvatar: (props) => <Avatar {...props} src='chatbot.png' />,
    },
    widgets: [
        {
            widgetName: 'options',
            widgetFunc: (props) => <Options {...props} />
        }
    ]
}

export default config;