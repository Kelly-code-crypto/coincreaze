import {makeStyles} from '@material-ui/core';

const useStyles = makeStyles({
    optionBtn: {
        backgroundColor: '#012241',
        color: 'white',
        margin: '5px 5px',
        padding: '5px 10px',
        borderRadius: '5px',
        border: 'none'
    }
});

const Options = (props) => {
    const classes = useStyles();
    const options = [
        {
            text: 'About Coincreaze',
            handler: () => {},
            id: 1
        },
        {
            text: 'Loan',
            handler: () => {},
            id: 2
        },
        {
            text: 'Invest',
            handler: () => {},
            id: 3
        }
    ]

    const buttonMarkup = options.map((option) => (
        <button key={option.id} onClick={option.handler} className={classes.optionBtn} >
            {option.text}
        </button>
    ))

    return <div>{buttonMarkup}</div>
}

export default Options;